RCINSTAEDIT — Professional Interface Prototype

This package contains an interactive mobile UI prototype. Open web/index.html in a browser.

It demonstrates:
- Professional dark/neon editor UI
- Photo Editor / Video Editor
- Effects
- Transitions
- Color grading controls
- Templates
- Audio import flow
- Timeline concept
- 1080p / 2K / 4K and FPS export UI

This is a prototype, not yet a production APK. A real Android editor needs a media engine/export pipeline; Android's current Jetpack Media3 Transformer supports trimming, scaling, rotation, overlays, filters, effects, image inputs and export, so it is suitable for implementing the production editor.
